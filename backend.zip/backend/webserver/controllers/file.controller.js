const db = require("../models");
const uuid =  require('uuid');
const path = require('path');
const File = db.file;

exports.clearSubfolder = (req, res) =>{
    const {subfolder} = req.body;
    File.deleteMany({subfolder:subfolder}).then(data=>{
        res.send(data);
        })
        .catch(err => {
        res.status(500).send({
            message: "Some error occurred while deleting the files",
            error: err.message
        });
        });
}

exports.addFiles = (req,res) => {
    const {user, subfolder} = req.body;
    const files = req.files;     
    const fileObjects = files.map((newFile)=>{
        let id = uuid.v4();
        return {
            subfolder:subfolder,
            fileName: newFile.originalname,
            user: user,
            systemFileName: newFile.filename,
            id
        }
    });
    File.insertMany(fileObjects).then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message: "Some error occurred while creating the new Files",
          error: err.message
        });
      });
}



exports.retrieveFileNames = (req, res) => {
    const subfolder = req.body.subfolder;
    let condition = subfolder ? { subfolder: { $regex: new RegExp(subfolder), $options: "i" } } : {};
    File.find({condition})
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving file names."
      });
    });
}

exports.retrieveFile = (req, res) => {
   const {id} = req.body;
    File.find({id:id})
    .then(data => {
        if (!data || data.length == 0) {
            res.status(404).send({
            message: `Cannot find File with id=${id}.`
            });
        }
        else{
          console.log(data);
            let file = data[0];
            let filePath = path.join(__dirname, '../assets/', file.subfolder, file.systemFileName);
            // Set the Content-Disposition header to suggest the file name
            // Set the Content-Disposition header to suggest the file name
            res.setHeader('Access-Control-Expose-Headers', 'Content-Disposition');
            res.setHeader('Content-Disposition', `attachment; filename="${file.fileName}"`);
            res.status(200).sendFile(filePath);
        }
      })
    .catch(err => {
        console.log(err.message);
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving goals."
      });
    });
}


