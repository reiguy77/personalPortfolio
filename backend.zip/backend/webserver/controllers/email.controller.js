const nodemailer = require('nodemailer');


exports.send = (req, res) => {
    let to = req.to;
    let from = req.from;
    let subject = req.subject;
    let text = req.text;

    // Create a transporter with the SMTP settings
    const transporter = nodemailer.createTransport({
    host: 'api.reillymclaren.com', // Replace with your DreamHost SMTP server
    port: 465, 
    secure: false, // Set to true if you're using SSL/TLS
    auth: {
        user: 'contact@api.reillymclaren.com', // Your email address
        pass: 'AJodyhighroller_77' // Your email password
    }
    });

    // Define the email content
    const mailOptions = {
        from: from, // Your email address
        to: to, // Recipient's email address
        subject: subject,
        text: text
    };

    // Send the email
    transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
        res.send({
            statusCode:400,
            message:error
        })
        console.error('Error sending email:', error);
    } else {
        res.send({
            statusCode:400,
            message:'Email sent successfully!'
        })
        console.log('Email sent:', info.response);
    }
    });


}